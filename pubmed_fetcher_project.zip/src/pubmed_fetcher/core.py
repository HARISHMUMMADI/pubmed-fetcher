def fetch_pubmed_data(query: str) -> list:
    return []  # logic placeholder